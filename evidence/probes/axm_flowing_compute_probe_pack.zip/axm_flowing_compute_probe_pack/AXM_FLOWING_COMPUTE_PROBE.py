from __future__ import annotations
import gc, json, hashlib, os, shutil, statistics, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'outputs/native-execution/2026-09-14T170409_0000_9dbfb79e1448/source'
sys.path.insert(0, str(SRC / 'src'))

from axm_framestate.canonical import normalize_project
from axm_framestate.effects import load_effect_library
from axm_framestate.media import MediaCache
from axm_framestate.render import render_frame

MESH = ROOT / 'examples/blackline-relay-3d-kit-v0.3/assets/relay_offline/source/relay_offline.obj'
OUT = ROOT / 'outputs/flowing-compute-probe'
FRAMES = 18
TRIALS = 7

raw = {
    'schema':'axm.framestate.project/v0.2',
    'id':'flowing-compute-relay-probe',
    'canvas':{'width':128,'height':96,'fps':12},
    'duration_frames':FRAMES,
    'background':[4,5,10],
    'camera':{'x':0,'y':0,'zoom_milli':1000},
    'media':[{'id':'relay','kind':'mesh','path':str(MESH)}],
    'layers':[{
        'id':'mesh','kind':'mesh3d','media_id':'relay','z':2,
        'start_frame':0,'end_frame':FRAMES,
        'x':0,'y':0,'depth':160,'size':80,
        'rot_x_mdeg':{'from':-10000,'to':25000},
        'rot_y_mdeg':{'from':0,'to':220000},
        'rot_z_mdeg':{'from':0,'to':18000},
        'color':[255,100,70]
    }],
    'captions':[], 'audio':[], 'effects':[], 'markers':[], 'metadata':{}
}
project = normalize_project(raw)
library = load_effect_library(SRC)


def digest_ppm(ppm: bytes) -> str:
    return hashlib.sha256(ppm).hexdigest()


def run_cold(trial: int):
    out = OUT / f'cold-{trial}'
    shutil.rmtree(out, ignore_errors=True); out.mkdir(parents=True)
    digests=[]
    cpu0=time.process_time_ns(); wall0=time.perf_counter_ns()
    for frame in range(FRAMES):
        cache=MediaCache(project,out,SRC)
        ppm,_=render_frame(project,frame,library,cache)
        digests.append(digest_ppm(ppm))
    cpu=time.process_time_ns()-cpu0; wall=time.perf_counter_ns()-wall0
    return cpu,wall,digests


def run_flow(trial: int):
    out = OUT / f'flow-{trial}'
    shutil.rmtree(out, ignore_errors=True); out.mkdir(parents=True)
    cpu0=time.process_time_ns(); wall0=time.perf_counter_ns()
    cache=MediaCache(project,out,SRC)
    digests=[]
    for frame in range(FRAMES):
        ppm,_=render_frame(project,frame,library,cache)
        digests.append(digest_ppm(ppm))
    cpu=time.process_time_ns()-cpu0; wall=time.perf_counter_ns()-wall0
    return cpu,wall,digests

# Warm interpreter and code paths before measured trials.
wc=MediaCache(project, OUT/'warm', SRC)
render_frame(project,0,library,wc)
shutil.rmtree(OUT/'warm', ignore_errors=True)

results=[]
reference=None
for trial in range(TRIALS):
    # Alternate order to reduce order/thermal/cache bias.
    order=('cold','flow') if trial%2==0 else ('flow','cold')
    row={'trial':trial+1,'order':list(order)}
    for mode in order:
        gc.collect()
        cpu,wall,digests=(run_cold(trial) if mode=='cold' else run_flow(trial))
        if reference is None: reference=digests
        if digests != reference:
            raise SystemExit(f'pixel digest mismatch in trial {trial+1} mode {mode}')
        row[mode]={'cpu_ns':cpu,'wall_ns':wall,'frame_digests':digests}
    results.append(row)

cold_cpu=[r['cold']['cpu_ns'] for r in results]
flow_cpu=[r['flow']['cpu_ns'] for r in results]
cold_wall=[r['cold']['wall_ns'] for r in results]
flow_wall=[r['flow']['wall_ns'] for r in results]
med_cold_cpu=statistics.median(cold_cpu); med_flow_cpu=statistics.median(flow_cpu)
med_cold_wall=statistics.median(cold_wall); med_flow_wall=statistics.median(flow_wall)
report={
 'schema':'axm.flowing-compute-monolith-probe/v0.1',
 'subject':{'monolith':'v0.4.30-WALMI-NATIVE-WIRING','workload':'FrameState deterministic mesh rendering','mesh':str(MESH.relative_to(ROOT)),'frames':FRAMES,'resolution':[128,96],'trials':TRIALS},
 'comparison':{
   'cold':'new MediaCache + media manifest + mesh parse state per frame',
   'flow':'one MediaCache initialized once, reused across all frames',
   'equivalent_output':True,
   'pixel_digests_identical':True
 },
 'median':{
   'cold_cpu_ns':med_cold_cpu,'flow_cpu_ns':med_flow_cpu,
   'cold_wall_ns':med_cold_wall,'flow_wall_ns':med_flow_wall,
   'cpu_saved_ns':med_cold_cpu-med_flow_cpu,
   'wall_saved_ns':med_cold_wall-med_flow_wall,
   'cpu_gain_percent':(med_cold_cpu-med_flow_cpu)/med_cold_cpu*100.0,
   'wall_gain_percent':(med_cold_wall-med_flow_wall)/med_cold_wall*100.0,
   'useful_yield_multiplier_cpu':med_cold_cpu/med_flow_cpu,
   'useful_yield_multiplier_wall':med_cold_wall/med_flow_wall
 },
 'trials':[{'trial':r['trial'],'order':r['order'],'cold_cpu_ns':r['cold']['cpu_ns'],'flow_cpu_ns':r['flow']['cpu_ns'],'cold_wall_ns':r['cold']['wall_ns'],'flow_wall_ns':r['flow']['wall_ns']} for r in results],
 'truth':{
   'this_is_real_monolith_code':True,
   'this_is_same_output_work':True,
   'this_proves_free_compute':False,
   'this_proves_general_scaling':False,
   'measured_effect_includes_avoided_reinitialization_manifest_hashing_and_repeated_mesh_parsing':True,
   'requires_independent_reproduction':True
 }
}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report['median'],indent=2))
print('REPORT',OUT/'report.json')
