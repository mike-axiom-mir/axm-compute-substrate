AXM Flowing Compute Probe Pack
2026-09-15

Built against:
AXM_Connected_Monolith_v0.4.30-WALMI-NATIVE-WIRING

Purpose:
Compare identical-output FrameState rendering when reusable media/mesh state is rebuilt per frame versus preserved across frames.

Observed on this host:
- Relay mesh run 1 median CPU reduction: 16.4983% (1.19758x useful-yield multiplier)
- Relay mesh run 2 median CPU reduction: 16.0063% (1.19057x useful-yield multiplier)
- Procedural cube control median CPU reduction: 0.6546% (1.00659x)

Truth boundary:
This demonstrates a bounded same-output efficiency gain from retained state in this workload. It is not evidence of free energy, physical over-unity, or universal scaling.

Usage:
Place AXM_FLOWING_COMPUTE_PROBE.py at the root of the same monolith version and run with Python 3.
The probe expects the FrameState native-execution snapshot and Blackline relay asset paths present in v0.4.30.
