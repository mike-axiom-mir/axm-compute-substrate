from __future__ import annotations
import gc,json,hashlib,shutil,statistics,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'outputs/native-execution/2026-09-14T170409_0000_9dbfb79e1448/source'
sys.path.insert(0,str(SRC/'src'))
from axm_framestate.canonical import load_project
from axm_framestate.effects import load_effect_library
from axm_framestate.media import MediaCache
from axm_framestate.render import render_frame
project=load_project(SRC/'examples/cube_cinematic.json')
lib=load_effect_library(SRC); OUT=ROOT/'outputs/flowing-compute-cube-probe'; FRAMES=12; project['duration_frames']=FRAMES; TRIALS=5

def d(x):return hashlib.sha256(x).hexdigest()
def cold(t):
 o=OUT/f'cold-{t}';shutil.rmtree(o,ignore_errors=True);o.mkdir(parents=True);ds=[];c0=time.process_time_ns();w0=time.perf_counter_ns()
 for f in range(FRAMES):
  cache=MediaCache(project,o,SRC);ppm,_=render_frame(project,f,lib,cache);ds.append(d(ppm))
 return time.process_time_ns()-c0,time.perf_counter_ns()-w0,ds
def flow(t):
 o=OUT/f'flow-{t}';shutil.rmtree(o,ignore_errors=True);o.mkdir(parents=True);c0=time.process_time_ns();w0=time.perf_counter_ns();cache=MediaCache(project,o,SRC);ds=[]
 for f in range(FRAMES):ppm,_=render_frame(project,f,lib,cache);ds.append(d(ppm))
 return time.process_time_ns()-c0,time.perf_counter_ns()-w0,ds
OUT.mkdir(parents=True,exist_ok=True);wc=MediaCache(project,OUT/'warm',SRC);render_frame(project,0,lib,wc);shutil.rmtree(OUT/'warm',ignore_errors=True)
rows=[];ref=None
for t in range(TRIALS):
 order=('cold','flow') if t%2==0 else ('flow','cold');r={'trial':t+1,'order':order}
 for mode in order:
  gc.collect();res=cold(t) if mode=='cold' else flow(t);r[mode]=res
  if ref is None:ref=res[2]
  assert res[2]==ref
 rows.append(r)
cc=[r['cold'][0] for r in rows];fc=[r['flow'][0] for r in rows];cw=[r['cold'][1] for r in rows];fw=[r['flow'][1] for r in rows]
mc,mf,mwc,mwf=map(statistics.median,(cc,fc,cw,fw))
rep={'schema':'axm.flowing-compute-monolith-probe/v0.1','subject':{'workload':'FrameState deterministic cube rendering','frames':FRAMES,'resolution':[128,96],'trials':TRIALS},'comparison':{'cold':'new MediaCache per frame','flow':'one MediaCache reused','pixel_digests_identical':True},'median':{'cold_cpu_ns':mc,'flow_cpu_ns':mf,'cpu_gain_percent':(mc-mf)/mc*100,'useful_yield_multiplier_cpu':mc/mf,'cold_wall_ns':mwc,'flow_wall_ns':mwf,'wall_gain_percent':(mwc-mwf)/mwc*100},'trials':[{'trial':r['trial'],'cold_cpu_ns':r['cold'][0],'flow_cpu_ns':r['flow'][0]} for r in rows],'truth':{'no_external_media_or_mesh':True,'this_proves_free_compute':False,'requires_independent_reproduction':True}}
(OUT/'report.json').write_text(json.dumps(rep,indent=2)+'\n');print(json.dumps(rep['median'],indent=2))
