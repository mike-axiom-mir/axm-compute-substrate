# AXM Flowing Compute Probe Pack v2

Runtime evidence generated from the uploaded copy of `AXM_Connected_Monolith_v0.4.30-WALMI-NATIVE-WIRING.zip` on 2026-09-15.

This pack extends the initial FrameState cold-vs-flow probe with:

1. **FrameState state decomposition** — separates manifest retention, parsed-mesh retention, and full retention.
2. **Frame-count scaling** — tests 1, 2, 4, 8, 18, and 36 frames with exact output digest equality.
3. **Execution Fabric status-state compilation** — compares reparsing the ~38 MB execution registry on every status request, retaining the full parsed registry, and retaining only the derived status state.

## Important truth boundary

These are single-host experiments on one copied monolith. They demonstrate repeatable compute savings from avoiding redundant reconstruction for specific workloads. They do not demonstrate free energy, physical over-unity, universal scaling, or a general percentage improvement for AXM.

The compiled Execution Fabric status test assumes the source snapshot is pinned/unchanged during the requests. A mutable production body requires an invalidation/freshness contract before reuse can be trusted.
