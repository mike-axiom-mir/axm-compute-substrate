from __future__ import annotations
import gc, hashlib, json, shutil, statistics, sys, time
from pathlib import Path
ROOT=Path('/mnt/data/mono_fc_test/AXM_Connected_Monolith_v0.4.30-WALMI-NATIVE-WIRING')
SRC=ROOT/'outputs/native-execution/2026-09-14T170409_0000_9dbfb79e1448/source'; sys.path.insert(0,str(SRC/'src'))
from axm_framestate.canonical import normalize_project
from axm_framestate.effects import load_effect_library
from axm_framestate.media import MediaCache
from axm_framestate.render import render_frame
MESH=ROOT/'examples/blackline-relay-3d-kit-v0.3/assets/relay_offline/source/relay_offline.obj'; OUT=ROOT/'outputs/flowing-compute-frame-scaling'; TRIALS=3
lib=load_effect_library(SRC)
def proj(n):
 raw={'schema':'axm.framestate.project/v0.2','id':f'fc-scale-{n}','canvas':{'width':128,'height':96,'fps':12},'duration_frames':n,'background':[4,5,10],'camera':{'x':0,'y':0,'zoom_milli':1000},'media':[{'id':'relay','kind':'mesh','path':str(MESH)}],'layers':[{'id':'mesh','kind':'mesh3d','media_id':'relay','z':2,'start_frame':0,'end_frame':n,'x':0,'y':0,'depth':160,'size':80,'rot_x_mdeg':{'from':-10000,'to':25000},'rot_y_mdeg':{'from':0,'to':220000},'rot_z_mdeg':{'from':0,'to':18000},'color':[255,100,70]}],'captions':[],'audio':[],'effects':[],'markers':[],'metadata':{}}
 return normalize_project(raw)
def digest(x):return hashlib.sha256(x).hexdigest()
def run(p,n,mode,t):
 out=OUT/f'n{n}-{mode}-{t}';shutil.rmtree(out,ignore_errors=True);out.mkdir(parents=True);ds=[];c0=time.process_time_ns();w0=time.perf_counter_ns()
 if mode=='flow':
  cache=MediaCache(p,out,SRC)
  for f in range(n): ppm,_=render_frame(p,f,lib,cache);ds.append(digest(ppm))
 else:
  for f in range(n):
   cache=MediaCache(p,out,SRC);ppm,_=render_frame(p,f,lib,cache);ds.append(digest(ppm))
 return time.process_time_ns()-c0,time.perf_counter_ns()-w0,ds
OUT.mkdir(parents=True,exist_ok=True); results=[]
for n in [1,2,4,8,18,36]:
 p=proj(n);wc=MediaCache(p,OUT/'warm',SRC);render_frame(p,0,lib,wc);shutil.rmtree(OUT/'warm',ignore_errors=True)
 rows=[];ref=None
 for t in range(TRIALS):
  order=['cold','flow'] if t%2==0 else ['flow','cold'];r={'trial':t+1}
  for mode in order:
   gc.collect();cpu,wall,ds=run(p,n,mode,t)
   if ref is None:ref=ds
   if ds!=ref:raise SystemExit(f'hash mismatch n={n} {mode}')
   r[mode]={'cpu_ns':cpu,'wall_ns':wall}
  rows.append(r)
 c=statistics.median([r['cold']['cpu_ns'] for r in rows]);f=statistics.median([r['flow']['cpu_ns'] for r in rows])
 results.append({'frames':n,'cold_cpu_median_ns':c,'flow_cpu_median_ns':f,'cpu_gain_percent':(c-f)/c*100,'yield_multiplier':c/f,'all_trials_flow_faster':all(r['flow']['cpu_ns']<r['cold']['cpu_ns'] for r in rows)})
report={'schema':'axm.flowing-compute-frame-scaling/v0.1','resolution':[128,96],'trials_per_point':TRIALS,'output_hashes_identical':True,'results':results,'truth':{'free_compute':False,'single_host':True}}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(results,indent=2))
