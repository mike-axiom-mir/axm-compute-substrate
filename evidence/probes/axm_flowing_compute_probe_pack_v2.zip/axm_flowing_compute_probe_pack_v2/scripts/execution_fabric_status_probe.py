from __future__ import annotations
import gc, hashlib, json, os, statistics, sys, time
from pathlib import Path
import psutil
ROOT=Path('/mnt/data/mono_fc_test/AXM_Connected_Monolith_v0.4.30-WALMI-NATIVE-WIRING')
sys.path.insert(0,str(ROOT))
import AXM_EXECUTION_FABRIC as fabric
REQUESTS=4
TRIALS=2
proc=psutil.Process(os.getpid())

def canonical(x): return json.dumps(x,sort_keys=True,separators=(',',':')).encode()

def rss(): return proc.memory_info().rss

def cold():
    outs=[]; c0=time.process_time_ns(); w0=time.perf_counter_ns(); peak=rss()
    for _ in range(REQUESTS):
        out=fabric.status(ROOT); outs.append(out); peak=max(peak,rss()); del out; gc.collect()
    return time.process_time_ns()-c0,time.perf_counter_ns()-w0,outs,peak

def resident():
    c0=time.process_time_ns(); w0=time.perf_counter_ns(); before=rss()
    root=fabric._validated_snapshot(ROOT); data=fabric.read_json(root/fabric.REGISTRY_NAME); evidence=root/fabric.EVIDENCE_ROOT
    setup_cpu=time.process_time_ns()-c0; setup_wall=time.perf_counter_ns()-w0; after_setup=rss()
    outs=[]
    for _ in range(REQUESTS):
        outs.append({'installed':True,'snapshot':str(root),**data.get('summary',{}),'probe_all':(evidence/'PROBE_ALL.json').is_file(),'test_all_broad':(evidence/'TEST_ALL_BROAD.json').is_file(),'test_all_exhaustive':(evidence/'TEST_ALL_EXHAUSTIVE.json').is_file()})
    total_cpu=time.process_time_ns()-c0; total_wall=time.perf_counter_ns()-w0
    return total_cpu,total_wall,setup_cpu,setup_wall,outs,before,after_setup,rss()

def compiled():
    c0=time.process_time_ns(); w0=time.perf_counter_ns(); before=rss()
    root=fabric._validated_snapshot(ROOT); data=fabric.read_json(root/fabric.REGISTRY_NAME); evidence=root/fabric.EVIDENCE_ROOT
    compiled_state={'installed':True,'snapshot':str(root),**data.get('summary',{}),'probe_all':(evidence/'PROBE_ALL.json').is_file(),'test_all_broad':(evidence/'TEST_ALL_BROAD.json').is_file(),'test_all_exhaustive':(evidence/'TEST_ALL_EXHAUSTIVE.json').is_file()}
    del data; gc.collect()
    setup_cpu=time.process_time_ns()-c0; setup_wall=time.perf_counter_ns()-w0; after_setup=rss()
    outs=[dict(compiled_state) for _ in range(REQUESTS)]
    total_cpu=time.process_time_ns()-c0; total_wall=time.perf_counter_ns()-w0
    return total_cpu,total_wall,setup_cpu,setup_wall,outs,before,after_setup,rss(),len(canonical(compiled_state))

# Warm module + filesystem path checks, but don't preparse registry.
fabric._validated_snapshot(ROOT)
rows=[]; ref=None
orders=[['cold','resident','compiled'],['compiled','cold','resident']]
for t,order in enumerate(orders,1):
    row={'trial':t,'order':order}
    for mode in order:
        gc.collect()
        if mode=='cold':
            cpu,wall,outs,peak=cold(); meta={'cpu_ns':cpu,'wall_ns':wall,'peak_rss':peak}
        elif mode=='resident':
            cpu,wall,sc,sw,outs,b,a,r=resident(); meta={'cpu_ns':cpu,'wall_ns':wall,'setup_cpu_ns':sc,'setup_wall_ns':sw,'rss_before':b,'rss_after_setup':a,'rss_end':r}
        else:
            cpu,wall,sc,sw,outs,b,a,r,cs=compiled(); meta={'cpu_ns':cpu,'wall_ns':wall,'setup_cpu_ns':sc,'setup_wall_ns':sw,'rss_before':b,'rss_after_setup':a,'rss_end':r,'compiled_state_bytes':cs}
        hashes=[hashlib.sha256(canonical(o)).hexdigest() for o in outs]
        if len(set(hashes))!=1: raise SystemExit(f'{mode} outputs varied')
        if ref is None: ref=hashes[0]
        if hashes[0]!=ref: raise SystemExit(f'{mode} output mismatch')
        row[mode]=meta
    rows.append(row)
summary={}
for mode in ['cold','resident','compiled']:
    cs=[r[mode]['cpu_ns'] for r in rows]; ws=[r[mode]['wall_ns'] for r in rows]
    summary[mode]={'cpu_median_ns':statistics.median(cs),'wall_median_ns':statistics.median(ws),'cpu_trials_ns':cs}
base=summary['cold']['cpu_median_ns']
for mode in ['resident','compiled']:
    summary[mode]['cpu_saved_percent_vs_cold']=(base-summary[mode]['cpu_median_ns'])/base*100
    summary[mode]['throughput_multiplier_vs_cold']=base/summary[mode]['cpu_median_ns']
report={'schema':'axm.flowing-compute-execution-fabric-status/v0.1','subject':{'registry':'EXECUTION_FABRIC.json','registry_bytes':(ROOT/'EXECUTION_FABRIC.json').stat().st_size,'requests':REQUESTS,'trials':TRIALS},'equivalence':{'exact_canonical_output_hash_match':True,'output_sha256':ref},'summary':summary,'rows':rows,'truth':{'same_status_answer':True,'cold_reparses_registry_every_request':True,'resident_retains_full_parsed_registry':True,'compiled_retains_only_derived_status_state':True,'free_compute':False,'single_host':True}}
out=ROOT/'outputs/flowing-compute-execution-fabric-status';out.mkdir(parents=True,exist_ok=True);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
