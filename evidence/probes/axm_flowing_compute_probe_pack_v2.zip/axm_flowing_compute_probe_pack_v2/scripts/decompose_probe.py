from __future__ import annotations
import gc, hashlib, json, shutil, statistics, sys, time
from pathlib import Path
ROOT=Path('/mnt/data/mono_fc_test/AXM_Connected_Monolith_v0.4.30-WALMI-NATIVE-WIRING')
SRC=ROOT/'outputs/native-execution/2026-09-14T170409_0000_9dbfb79e1448/source'
sys.path.insert(0,str(SRC/'src'))
from axm_framestate.canonical import normalize_project
from axm_framestate.effects import load_effect_library
from axm_framestate.media import MediaCache
from axm_framestate.render import render_frame
from axm_framestate.three_d import parse_obj
MESH=ROOT/'examples/blackline-relay-3d-kit-v0.3/assets/relay_offline/source/relay_offline.obj'
OUT=ROOT/'outputs/flowing-compute-decompose'
FRAMES=18; TRIALS=5
raw={'schema':'axm.framestate.project/v0.2','id':'fc-decompose','canvas':{'width':128,'height':96,'fps':12},'duration_frames':FRAMES,'background':[4,5,10],'camera':{'x':0,'y':0,'zoom_milli':1000},'media':[{'id':'relay','kind':'mesh','path':str(MESH)}],'layers':[{'id':'mesh','kind':'mesh3d','media_id':'relay','z':2,'start_frame':0,'end_frame':FRAMES,'x':0,'y':0,'depth':160,'size':80,'rot_x_mdeg':{'from':-10000,'to':25000},'rot_y_mdeg':{'from':0,'to':220000},'rot_z_mdeg':{'from':0,'to':18000},'color':[255,100,70]}],'captions':[],'audio':[],'effects':[],'markers':[],'metadata':{}}
project=normalize_project(raw); lib=load_effect_library(SRC)
def d(ppm): return hashlib.sha256(ppm).hexdigest()
def run(mode,t):
    out=OUT/f'{mode}-{t}'; shutil.rmtree(out,ignore_errors=True); out.mkdir(parents=True)
    ds=[]; c0=time.process_time_ns(); w0=time.perf_counter_ns()
    if mode=='flow':
        cache=MediaCache(project,out,SRC)
        for f in range(FRAMES):
            ppm,_=render_frame(project,f,lib,cache); ds.append(d(ppm))
    elif mode=='cold':
        for f in range(FRAMES):
            cache=MediaCache(project,out,SRC); ppm,_=render_frame(project,f,lib,cache); ds.append(d(ppm))
    elif mode=='manifest_persist':
        cache=MediaCache(project,out,SRC)
        for f in range(FRAMES):
            cache._mesh.clear(); ppm,_=render_frame(project,f,lib,cache); ds.append(d(ppm))
    elif mode=='mesh_persist':
        parsed=parse_obj(MESH)
        for f in range(FRAMES):
            cache=MediaCache(project,out,SRC); cache._mesh['relay']=parsed; ppm,_=render_frame(project,f,lib,cache); ds.append(d(ppm))
    else: raise ValueError(mode)
    return time.process_time_ns()-c0,time.perf_counter_ns()-w0,ds
OUT.mkdir(parents=True,exist_ok=True)
# warm
wc=MediaCache(project,OUT/'warm',SRC); render_frame(project,0,lib,wc); shutil.rmtree(OUT/'warm',ignore_errors=True)
modes=['cold','manifest_persist','mesh_persist','flow']; rows=[]; ref=None
orders=[modes, list(reversed(modes)), ['mesh_persist','flow','cold','manifest_persist'], ['flow','manifest_persist','mesh_persist','cold'], ['manifest_persist','cold','flow','mesh_persist']]
for t in range(TRIALS):
    row={'trial':t+1,'order':orders[t]}
    for mode in orders[t]:
        gc.collect(); cpu,wall,ds=run(mode,t)
        if ref is None: ref=ds
        if ds!=ref: raise SystemExit(f'digest mismatch {mode} trial {t+1}')
        row[mode]={'cpu_ns':cpu,'wall_ns':wall}
    rows.append(row)
summary={}
for mode in modes:
    cp=[r[mode]['cpu_ns'] for r in rows]; wp=[r[mode]['wall_ns'] for r in rows]
    summary[mode]={'cpu_median_ns':statistics.median(cp),'wall_median_ns':statistics.median(wp),'cpu_trials_ns':cp}
base=summary['cold']['cpu_median_ns']
for mode in modes:
    summary[mode]['cpu_gain_vs_cold_percent']=(base-summary[mode]['cpu_median_ns'])/base*100
    summary[mode]['yield_vs_cold']=base/summary[mode]['cpu_median_ns']
report={'schema':'axm.flowing-compute-decomposition/v0.1','frames':FRAMES,'trials':TRIALS,'output_hashes_identical':True,'summary':summary,'rows':rows,'truth':{'component_differences_overlap':True,'not_additive_proof':True,'free_compute':False}}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(summary,indent=2))
